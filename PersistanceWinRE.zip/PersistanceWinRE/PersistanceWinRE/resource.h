//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PersistanceWinRE.rc


#define IDR_DLL_PAYLOAD                  101
#define IDR_RESET_CONFIG				 102
#define IDR_CMD_SCRIPT					 103
