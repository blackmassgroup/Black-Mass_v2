#pragma once
#include <filesystem>
#include <Windows.h>

#define MAX_SIZE_STRING 302
using _QWORD = unsigned long long;

#define CONCAT( X, Y ) X##Y

struct XmlInformation
{
	DWORD dwFlagIsEnabled; //Core way for knowing if the computer has WinRE.
	DWORD dwIsImageStaged;
	BYTE Reserved1[12];
	wchar_t WinReFilePath[MAX_SIZE_STRING]; //Path 1
	wchar_t WimInstalledLocation[MAX_SIZE_STRING]; //Path 2
	_GUID GuidInfo; //GUID used, not sure from where it gets it.
	wchar_t setupDirectoryLocation[MAX_SIZE_STRING];
	DWORD Index2;
	wchar_t CustomImageLocation[MAX_SIZE_STRING];
	DWORD Index1;
	BYTE Reserved2[4];
	wchar_t copyOperationParam[MAX_SIZE_STRING];
	BYTE Reserved3[16];
	DWORD dwFlagSet;
	BYTE WimHashData[32];
	DWORD dwSizeWimHashData;
	wchar_t DownlevelWinreLocation[MAX_SIZE_STRING];
	BYTE Reserved4[8];
};

typedef struct WinReManagerConfig
{
	_QWORD SizeOfStruct;
	XmlInformation InfoWinRe;
}WINRE_CONFIG, * PWINRE_CONFIG;

template< typename modHandleType, typename procNameType >
auto getProcAddressOrThrow(modHandleType modHandle, procNameType procName) {
	auto address = GetProcAddress(modHandle, procName);
	if (address == nullptr) throw std::exception{ (std::string{"Error importing: "} + (std::string{procName})).c_str() };
	return address;
}

#define CONCAT( id1, id2 ) id1##id2
#define IMPORTAPI( DLLFILE, FUNCNAME, RETTYPE, ... )                                                                        \
   typedef RETTYPE( WINAPI* CONCAT( t_, FUNCNAME ) )( __VA_ARGS__ );                                                        \
   template< typename... Ts >                                                                                               \
   auto FUNCNAME( Ts... ts ) {                                                                                              \
      const static CONCAT( t_, FUNCNAME ) func =                                                                            \
       (CONCAT( t_, FUNCNAME )) getProcAddressOrThrow( ( LoadLibrary( DLLFILE ), GetModuleHandle( DLLFILE ) ), #FUNCNAME ); \
      return func( std::forward< Ts >( ts )... );                                                                           \
   }; 
