#pragma once
#include "windefs.h"
#include "winre.hpp"
#include <tuple>
#include <array>
#include <iostream>


namespace WinRe
{
	enum CORE_FILES
	{
		RESET_CONFIG_XML = 0,
		DEFAULT_EXTENSIBILITY_SCRIPT = 1,
		PAYLOAD_DLL = 2
	};
	
	class SecurityManager 
	{
		public:
			void CreateSetSecurityFolder(const std::wstring& folderPath);
			bool CreateSetSecurityFiles(const std::wstring& FilePath) noexcept;
			bool DropResourceToFile(HANDLE& hFile, const DWORD dwIDRes) noexcept;
			DWORD GetIdentifierRes(auto FilePath);
		private:
			DWORD dwErrorCodeFolder, dwErrorCodeFiles[3];
	};
	
	class FileManager : public SecurityManager
	{
		public:
			FileManager(void);
			void ScanAndSetDirectoryRecovery(void);
			void ScanAndSetCoreFiles(void);
			const std::wstring& GetCoreFile(CORE_FILES index) noexcept;
			bool setFolder, setFiles;
		private:
			std::wstring m_RecoveryPath;
			std::array<std::wstring, 3> m_CoreFiles;
	};

	class WinReManager : public FileManager
	{
		public:
			WinReManager(void);
			auto GetCurrentWinReInformation(void) -> std::tuple <bool, LPCWSTR>;
		private:
			WinReManagerConfig config;
	};

};